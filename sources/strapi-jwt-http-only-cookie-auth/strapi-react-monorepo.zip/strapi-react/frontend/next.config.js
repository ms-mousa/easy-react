module.exports = {
  env: {
    BACKEND_URL: 'http://localhost:1337',
    GLOBAL_ERROR_MESSAGE:
      'Opps! Something went wrong. Please contact support@xstocks.com',
  },
};
