import { Center, Spinner } from '@chakra-ui/react';
import { Layout } from '../components/layout/Layout';

const Index: React.FC = () => (
  <Layout protectedContent>
    <Center w="100%" bg="yellow.200">
      <Spinner size="xl" thickness="8px" />
    </Center>
  </Layout>
);

export default Index;
