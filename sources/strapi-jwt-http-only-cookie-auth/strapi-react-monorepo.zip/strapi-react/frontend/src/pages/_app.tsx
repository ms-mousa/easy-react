import { AppProps } from 'next/app';
import { ChakraProvider } from '@chakra-ui/react';
import Head from 'next/head';
import { SWRConfig } from 'swr';
import { axiosFetcher } from '../lib/axios';
import theme from '../theme';

const SWROptions = {
  revalidateOnFocus: false,
  revalidateOnReconnect: false,
  fetcher: axiosFetcher,
};

function MyApp({ Component, pageProps }: AppProps) {
  return (
    <ChakraProvider resetCSS theme={theme}>
      <SWRConfig value={SWROptions}>
        <Head>
          <title>XStocks App</title>
          <meta
            name="description"
            content="A stock tracking app for managing your portfolio"
          />
          <meta name="viewport" content="initial-scale=1.0, width=device-width" />
          <link rel="icon" type="image/x-icon" href="../favicon.ico" />
        </Head>
        <Component {...pageProps} />
      </SWRConfig>
      <Component {...pageProps} />
    </ChakraProvider>
  );
}

export default MyApp;
