import useSWR from 'swr';
import { axiosFetcher } from '../lib/axios';

interface User {
  firstName: string;
  lastName: string;
  id: string;
}

interface UseUser {
  loading: boolean;
  error: Error;
  user: User;
}

export function useUser(): UseUser {
  const { data: user, error } = useSWR('/users/me', axiosFetcher);

  return {
    error,
    loading: !error && !user,
    user,
  };
}
