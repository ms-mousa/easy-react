import useSWR, { cache } from 'swr';

export function useSWRWithCache(url: string, query = true): { data: any; error: Error } {
  const { data, error } = useSWR(query ? url : null, {
    revalidateOnMount: !cache.has(url),
  });

  return {
    data,
    error,
  };
}
