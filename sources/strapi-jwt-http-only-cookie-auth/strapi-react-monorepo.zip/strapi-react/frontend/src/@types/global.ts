/* eslint-disable no-shadow */
export enum LoginPageSections {
  ForgotPassword = 'forgotpassword',
  NewAccount = 'newaccount',
}
