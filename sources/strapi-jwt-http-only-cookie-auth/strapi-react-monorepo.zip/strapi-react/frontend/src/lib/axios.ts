import axios from 'axios';

export const Axios = axios.create({
  baseURL: process.env.BACKEND_URL,
  withCredentials: true,
  headers: {
    Accept: 'application/json',
    'Content-Type': 'application/json',
  },
});

// TODO: Add catch phrase very important to invalidate non proper user
export const axiosFetcher = (url: string): any => Axios.get(url).then((res) => res.data);
