import {
  Center,
  Flex,
  FlexProps,
  Grid,
  GridItem,
  Spinner,
  useStyleConfig,
} from '@chakra-ui/react';
import { useRouter } from 'next/router';
import { useEffect } from 'react';
import { useUser } from '../../hooks/useUser';

interface ILayoutProps extends FlexProps {
  protectedContent?: boolean;
  children: React.ReactNode;
}
export const Layout: React.FC<ILayoutProps> = (props) => {
  const { protectedContent, children, ...rest } = props;
  const { user, loading } = useUser();
  const router = useRouter();
  const layoutStyles = useStyleConfig('Layout');

  useEffect(() => {
    if (protectedContent && !loading && !user) {
      router.push('/login');
    }
  }, [user, protectedContent, loading, router]);

  if (loading || (!user && protectedContent))
    return (
      <Center w="100%" h="100vh">
        <Spinner />
      </Center>
    );

  return (
    <Grid sx={layoutStyles} {...rest}>
      <GridItem position="sticky" top={0} zIndex={1000} colSpan={2}>
        {/* <AppHeader />  */}
        HEADER
      </GridItem>
      <GridItem display={['none', 'none', 'none', 'initial']} rowSpan={2}>
        SIDEBAR
        {/* <SideBar /> */}
      </GridItem>
      <GridItem display="flex" justifyContent="center" m={[2, 2, 4, 4]}>
        <Flex w="100%" maxW="70rem">
          {children}
        </Flex>
      </GridItem>
    </Grid>
  );
};
