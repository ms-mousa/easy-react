module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/pages/index.tsx");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/components/layout/Layout.tsx":
/*!******************************************!*\
  !*** ./src/components/layout/Layout.tsx ***!
  \******************************************/
/*! exports provided: Layout */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"Layout\", function() { return Layout; });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @chakra-ui/react */ \"@chakra-ui/react\");\n/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _hooks_useUser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../hooks/useUser */ \"./src/hooks/useUser.ts\");\n\nvar _jsxFileName = \"/Users/msmo/Documents/next-easy-react/frontend/src/components/layout/Layout.tsx\";\n\nfunction ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }\n\nfunction _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }\n\nfunction _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }\n\nfunction _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }\n\nfunction _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }\n\n\n\n\n\nconst Layout = props => {\n  const {\n    protectedContent,\n    children\n  } = props,\n        rest = _objectWithoutProperties(props, [\"protectedContent\", \"children\"]);\n\n  const {\n    user,\n    loading\n  } = Object(_hooks_useUser__WEBPACK_IMPORTED_MODULE_4__[\"useUser\"])();\n  const router = Object(next_router__WEBPACK_IMPORTED_MODULE_2__[\"useRouter\"])();\n  const layoutStyles = Object(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__[\"useStyleConfig\"])('Layout');\n  Object(react__WEBPACK_IMPORTED_MODULE_3__[\"useEffect\"])(() => {\n    if (protectedContent && !loading && !user) {\n      router.push('/login');\n    }\n  }, [user, protectedContent, loading, router]);\n  if (loading || !user && protectedContent) return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__[\"jsxDEV\"])(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__[\"Center\"], {\n    w: \"100%\",\n    h: \"100vh\",\n    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__[\"jsxDEV\"])(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__[\"Spinner\"], {}, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 33,\n      columnNumber: 9\n    }, undefined)\n  }, void 0, false, {\n    fileName: _jsxFileName,\n    lineNumber: 32,\n    columnNumber: 7\n  }, undefined);\n  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__[\"jsxDEV\"])(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__[\"Grid\"], _objectSpread(_objectSpread({\n    sx: layoutStyles\n  }, rest), {}, {\n    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__[\"jsxDEV\"])(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__[\"GridItem\"], {\n      position: \"sticky\",\n      top: 0,\n      zIndex: 1000,\n      colSpan: 2,\n      children: \"HEADER\"\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 39,\n      columnNumber: 7\n    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__[\"jsxDEV\"])(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__[\"GridItem\"], {\n      display: ['none', 'none', 'none', 'initial'],\n      rowSpan: 2,\n      children: \"SIDEBAR\"\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 43,\n      columnNumber: 7\n    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__[\"jsxDEV\"])(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__[\"GridItem\"], {\n      display: \"flex\",\n      justifyContent: \"center\",\n      m: [2, 2, 4, 4],\n      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__[\"jsxDEV\"])(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__[\"Flex\"], {\n        w: \"100%\",\n        maxW: \"70rem\",\n        children: children\n      }, void 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 48,\n        columnNumber: 9\n      }, undefined)\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 47,\n      columnNumber: 7\n    }, undefined)]\n  }), void 0, true, {\n    fileName: _jsxFileName,\n    lineNumber: 38,\n    columnNumber: 5\n  }, undefined);\n};//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9sYXlvdXQvTGF5b3V0LnRzeD85NjQxIl0sIm5hbWVzIjpbIkxheW91dCIsInByb3BzIiwicHJvdGVjdGVkQ29udGVudCIsImNoaWxkcmVuIiwicmVzdCIsInVzZXIiLCJsb2FkaW5nIiwidXNlVXNlciIsInJvdXRlciIsInVzZVJvdXRlciIsImxheW91dFN0eWxlcyIsInVzZVN0eWxlQ29uZmlnIiwidXNlRWZmZWN0IiwicHVzaCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFTQTtBQUNBO0FBQ0E7QUFNTyxNQUFNQSxNQUE4QixHQUFJQyxLQUFELElBQVc7QUFDdkQsUUFBTTtBQUFFQyxvQkFBRjtBQUFvQkM7QUFBcEIsTUFBMENGLEtBQWhEO0FBQUEsUUFBdUNHLElBQXZDLDRCQUFnREgsS0FBaEQ7O0FBQ0EsUUFBTTtBQUFFSSxRQUFGO0FBQVFDO0FBQVIsTUFBb0JDLDhEQUFPLEVBQWpDO0FBQ0EsUUFBTUMsTUFBTSxHQUFHQyw2REFBUyxFQUF4QjtBQUNBLFFBQU1DLFlBQVksR0FBR0MsdUVBQWMsQ0FBQyxRQUFELENBQW5DO0FBRUFDLHlEQUFTLENBQUMsTUFBTTtBQUNkLFFBQUlWLGdCQUFnQixJQUFJLENBQUNJLE9BQXJCLElBQWdDLENBQUNELElBQXJDLEVBQTJDO0FBQ3pDRyxZQUFNLENBQUNLLElBQVAsQ0FBWSxRQUFaO0FBQ0Q7QUFDRixHQUpRLEVBSU4sQ0FBQ1IsSUFBRCxFQUFPSCxnQkFBUCxFQUF5QkksT0FBekIsRUFBa0NFLE1BQWxDLENBSk0sQ0FBVDtBQU1BLE1BQUlGLE9BQU8sSUFBSyxDQUFDRCxJQUFELElBQVNILGdCQUF6QixFQUNFLG9CQUNFLHFFQUFDLHVEQUFEO0FBQVEsS0FBQyxFQUFDLE1BQVY7QUFBaUIsS0FBQyxFQUFDLE9BQW5CO0FBQUEsMkJBQ0UscUVBQUMsd0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQU1GLHNCQUNFLHFFQUFDLHFEQUFEO0FBQU0sTUFBRSxFQUFFUTtBQUFWLEtBQTRCTixJQUE1QjtBQUFBLDRCQUNFLHFFQUFDLHlEQUFEO0FBQVUsY0FBUSxFQUFDLFFBQW5CO0FBQTRCLFNBQUcsRUFBRSxDQUFqQztBQUFvQyxZQUFNLEVBQUUsSUFBNUM7QUFBa0QsYUFBTyxFQUFFLENBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBS0UscUVBQUMseURBQUQ7QUFBVSxhQUFPLEVBQUUsQ0FBQyxNQUFELEVBQVMsTUFBVCxFQUFpQixNQUFqQixFQUF5QixTQUF6QixDQUFuQjtBQUF3RCxhQUFPLEVBQUUsQ0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTEYsZUFTRSxxRUFBQyx5REFBRDtBQUFVLGFBQU8sRUFBQyxNQUFsQjtBQUF5QixvQkFBYyxFQUFDLFFBQXhDO0FBQWlELE9BQUMsRUFBRSxDQUFDLENBQUQsRUFBSSxDQUFKLEVBQU8sQ0FBUCxFQUFVLENBQVYsQ0FBcEQ7QUFBQSw2QkFDRSxxRUFBQyxxREFBRDtBQUFNLFNBQUMsRUFBQyxNQUFSO0FBQWUsWUFBSSxFQUFDLE9BQXBCO0FBQUEsa0JBQ0dEO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFpQkQsQ0FwQ00iLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9sYXlvdXQvTGF5b3V0LnRzeC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIENlbnRlcixcbiAgRmxleCxcbiAgRmxleFByb3BzLFxuICBHcmlkLFxuICBHcmlkSXRlbSxcbiAgU3Bpbm5lcixcbiAgdXNlU3R5bGVDb25maWcsXG59IGZyb20gJ0BjaGFrcmEtdWkvcmVhY3QnO1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSAnbmV4dC9yb3V0ZXInO1xuaW1wb3J0IHsgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlVXNlciB9IGZyb20gJy4uLy4uL2hvb2tzL3VzZVVzZXInO1xuXG5pbnRlcmZhY2UgSUxheW91dFByb3BzIGV4dGVuZHMgRmxleFByb3BzIHtcbiAgcHJvdGVjdGVkQ29udGVudD86IGJvb2xlYW47XG4gIGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7XG59XG5leHBvcnQgY29uc3QgTGF5b3V0OiBSZWFjdC5GQzxJTGF5b3V0UHJvcHM+ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHsgcHJvdGVjdGVkQ29udGVudCwgY2hpbGRyZW4sIC4uLnJlc3QgfSA9IHByb3BzO1xuICBjb25zdCB7IHVzZXIsIGxvYWRpbmcgfSA9IHVzZVVzZXIoKTtcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG4gIGNvbnN0IGxheW91dFN0eWxlcyA9IHVzZVN0eWxlQ29uZmlnKCdMYXlvdXQnKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChwcm90ZWN0ZWRDb250ZW50ICYmICFsb2FkaW5nICYmICF1c2VyKSB7XG4gICAgICByb3V0ZXIucHVzaCgnL2xvZ2luJyk7XG4gICAgfVxuICB9LCBbdXNlciwgcHJvdGVjdGVkQ29udGVudCwgbG9hZGluZywgcm91dGVyXSk7XG5cbiAgaWYgKGxvYWRpbmcgfHwgKCF1c2VyICYmIHByb3RlY3RlZENvbnRlbnQpKVxuICAgIHJldHVybiAoXG4gICAgICA8Q2VudGVyIHc9XCIxMDAlXCIgaD1cIjEwMHZoXCI+XG4gICAgICAgIDxTcGlubmVyIC8+XG4gICAgICA8L0NlbnRlcj5cbiAgICApO1xuXG4gIHJldHVybiAoXG4gICAgPEdyaWQgc3g9e2xheW91dFN0eWxlc30gey4uLnJlc3R9PlxuICAgICAgPEdyaWRJdGVtIHBvc2l0aW9uPVwic3RpY2t5XCIgdG9wPXswfSB6SW5kZXg9ezEwMDB9IGNvbFNwYW49ezJ9PlxuICAgICAgICB7LyogPEFwcEhlYWRlciAvPiAgKi99XG4gICAgICAgIEhFQURFUlxuICAgICAgPC9HcmlkSXRlbT5cbiAgICAgIDxHcmlkSXRlbSBkaXNwbGF5PXtbJ25vbmUnLCAnbm9uZScsICdub25lJywgJ2luaXRpYWwnXX0gcm93U3Bhbj17Mn0+XG4gICAgICAgIFNJREVCQVJcbiAgICAgICAgey8qIDxTaWRlQmFyIC8+ICovfVxuICAgICAgPC9HcmlkSXRlbT5cbiAgICAgIDxHcmlkSXRlbSBkaXNwbGF5PVwiZmxleFwiIGp1c3RpZnlDb250ZW50PVwiY2VudGVyXCIgbT17WzIsIDIsIDQsIDRdfT5cbiAgICAgICAgPEZsZXggdz1cIjEwMCVcIiBtYXhXPVwiNzByZW1cIj5cbiAgICAgICAgICB7Y2hpbGRyZW59XG4gICAgICAgIDwvRmxleD5cbiAgICAgIDwvR3JpZEl0ZW0+XG4gICAgPC9HcmlkPlxuICApO1xufTtcbiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/components/layout/Layout.tsx\n");

/***/ }),

/***/ "./src/hooks/useUser.ts":
/*!******************************!*\
  !*** ./src/hooks/useUser.ts ***!
  \******************************/
/*! exports provided: useUser */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"useUser\", function() { return useUser; });\n/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! swr */ \"swr\");\n/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(swr__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _lib_axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../lib/axios */ \"./src/lib/axios.ts\");\n\n\nfunction useUser() {\n  const {\n    data: user,\n    error\n  } = swr__WEBPACK_IMPORTED_MODULE_0___default()('/users/me', _lib_axios__WEBPACK_IMPORTED_MODULE_1__[\"axiosFetcher\"]);\n  return {\n    error,\n    loading: !error && !user,\n    user\n  };\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvaG9va3MvdXNlVXNlci50cz8zOGM4Il0sIm5hbWVzIjpbInVzZVVzZXIiLCJkYXRhIiwidXNlciIsImVycm9yIiwidXNlU1dSIiwiYXhpb3NGZXRjaGVyIiwibG9hZGluZyJdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFjTyxTQUFTQSxPQUFULEdBQTRCO0FBQ2pDLFFBQU07QUFBRUMsUUFBSSxFQUFFQyxJQUFSO0FBQWNDO0FBQWQsTUFBd0JDLDBDQUFNLENBQUMsV0FBRCxFQUFjQyx1REFBZCxDQUFwQztBQUVBLFNBQU87QUFDTEYsU0FESztBQUVMRyxXQUFPLEVBQUUsQ0FBQ0gsS0FBRCxJQUFVLENBQUNELElBRmY7QUFHTEE7QUFISyxHQUFQO0FBS0QiLCJmaWxlIjoiLi9zcmMvaG9va3MvdXNlVXNlci50cy5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB1c2VTV1IgZnJvbSAnc3dyJztcbmltcG9ydCB7IGF4aW9zRmV0Y2hlciB9IGZyb20gJy4uL2xpYi9heGlvcyc7XG5cbmludGVyZmFjZSBVc2VyIHtcbiAgZmlyc3ROYW1lOiBzdHJpbmc7XG4gIGxhc3ROYW1lOiBzdHJpbmc7XG4gIGlkOiBzdHJpbmc7XG59XG5cbmludGVyZmFjZSBVc2VVc2VyIHtcbiAgbG9hZGluZzogYm9vbGVhbjtcbiAgZXJyb3I6IEVycm9yO1xuICB1c2VyOiBVc2VyO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdXNlVXNlcigpOiBVc2VVc2VyIHtcbiAgY29uc3QgeyBkYXRhOiB1c2VyLCBlcnJvciB9ID0gdXNlU1dSKCcvdXNlcnMvbWUnLCBheGlvc0ZldGNoZXIpO1xuXG4gIHJldHVybiB7XG4gICAgZXJyb3IsXG4gICAgbG9hZGluZzogIWVycm9yICYmICF1c2VyLFxuICAgIHVzZXIsXG4gIH07XG59XG4iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/hooks/useUser.ts\n");

/***/ }),

/***/ "./src/lib/axios.ts":
/*!**************************!*\
  !*** ./src/lib/axios.ts ***!
  \**************************/
/*! exports provided: Axios, axiosFetcher */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"Axios\", function() { return Axios; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"axiosFetcher\", function() { return axiosFetcher; });\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ \"axios\");\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);\n\nconst Axios = axios__WEBPACK_IMPORTED_MODULE_0___default.a.create({\n  baseURL: \"http://localhost:1337\",\n  withCredentials: true,\n  headers: {\n    Accept: 'application/json',\n    'Content-Type': 'application/json'\n  }\n}); // TODO: Add catch phrase very important to invalidate non proper user\n\nconst axiosFetcher = url => Axios.get(url).then(res => res.data);//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvbGliL2F4aW9zLnRzP2Y3MDUiXSwibmFtZXMiOlsiQXhpb3MiLCJheGlvcyIsImNyZWF0ZSIsImJhc2VVUkwiLCJwcm9jZXNzIiwid2l0aENyZWRlbnRpYWxzIiwiaGVhZGVycyIsIkFjY2VwdCIsImF4aW9zRmV0Y2hlciIsInVybCIsImdldCIsInRoZW4iLCJyZXMiLCJkYXRhIl0sIm1hcHBpbmdzIjoiQUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFTyxNQUFNQSxLQUFLLEdBQUdDLDRDQUFLLENBQUNDLE1BQU4sQ0FBYTtBQUNoQ0MsU0FBTyxFQUFFQyx1QkFEdUI7QUFFaENDLGlCQUFlLEVBQUUsSUFGZTtBQUdoQ0MsU0FBTyxFQUFFO0FBQ1BDLFVBQU0sRUFBRSxrQkFERDtBQUVQLG9CQUFnQjtBQUZUO0FBSHVCLENBQWIsQ0FBZCxDLENBU1A7O0FBQ08sTUFBTUMsWUFBWSxHQUFJQyxHQUFELElBQXNCVCxLQUFLLENBQUNVLEdBQU4sQ0FBVUQsR0FBVixFQUFlRSxJQUFmLENBQXFCQyxHQUFELElBQVNBLEdBQUcsQ0FBQ0MsSUFBakMsQ0FBM0MiLCJmaWxlIjoiLi9zcmMvbGliL2F4aW9zLnRzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGF4aW9zIGZyb20gJ2F4aW9zJztcblxuZXhwb3J0IGNvbnN0IEF4aW9zID0gYXhpb3MuY3JlYXRlKHtcbiAgYmFzZVVSTDogcHJvY2Vzcy5lbnYuQkFDS0VORF9VUkwsXG4gIHdpdGhDcmVkZW50aWFsczogdHJ1ZSxcbiAgaGVhZGVyczoge1xuICAgIEFjY2VwdDogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gIH0sXG59KTtcblxuLy8gVE9ETzogQWRkIGNhdGNoIHBocmFzZSB2ZXJ5IGltcG9ydGFudCB0byBpbnZhbGlkYXRlIG5vbiBwcm9wZXIgdXNlclxuZXhwb3J0IGNvbnN0IGF4aW9zRmV0Y2hlciA9ICh1cmw6IHN0cmluZyk6IGFueSA9PiBBeGlvcy5nZXQodXJsKS50aGVuKChyZXMpID0+IHJlcy5kYXRhKTtcbiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/lib/axios.ts\n");

/***/ }),

/***/ "./src/pages/index.tsx":
/*!*****************************!*\
  !*** ./src/pages/index.tsx ***!
  \*****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @chakra-ui/react */ \"@chakra-ui/react\");\n/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _components_layout_Layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/layout/Layout */ \"./src/components/layout/Layout.tsx\");\n\nvar _jsxFileName = \"/Users/msmo/Documents/next-easy-react/frontend/src/pages/index.tsx\";\n\n\n\nconst Index = () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__[\"jsxDEV\"])(_components_layout_Layout__WEBPACK_IMPORTED_MODULE_2__[\"Layout\"], {\n  protectedContent: true,\n  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__[\"jsxDEV\"])(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__[\"Center\"], {\n    w: \"100%\",\n    bg: \"yellow.200\",\n    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__[\"jsxDEV\"])(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__[\"Spinner\"], {\n      size: \"xl\",\n      thickness: \"8px\"\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 7,\n      columnNumber: 7\n    }, undefined)\n  }, void 0, false, {\n    fileName: _jsxFileName,\n    lineNumber: 6,\n    columnNumber: 5\n  }, undefined)\n}, void 0, false, {\n  fileName: _jsxFileName,\n  lineNumber: 5,\n  columnNumber: 3\n}, undefined);\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (Index);//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvcGFnZXMvaW5kZXgudHN4PzQxZTAiXSwibmFtZXMiOlsiSW5kZXgiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUE7QUFDQTs7QUFFQSxNQUFNQSxLQUFlLEdBQUcsbUJBQ3RCLHFFQUFDLGdFQUFEO0FBQVEsa0JBQWdCLE1BQXhCO0FBQUEseUJBQ0UscUVBQUMsdURBQUQ7QUFBUSxLQUFDLEVBQUMsTUFBVjtBQUFpQixNQUFFLEVBQUMsWUFBcEI7QUFBQSwyQkFDRSxxRUFBQyx3REFBRDtBQUFTLFVBQUksRUFBQyxJQUFkO0FBQW1CLGVBQVMsRUFBQztBQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFERjs7QUFRZUEsb0VBQWYiLCJmaWxlIjoiLi9zcmMvcGFnZXMvaW5kZXgudHN4LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ2VudGVyLCBTcGlubmVyIH0gZnJvbSAnQGNoYWtyYS11aS9yZWFjdCc7XG5pbXBvcnQgeyBMYXlvdXQgfSBmcm9tICcuLi9jb21wb25lbnRzL2xheW91dC9MYXlvdXQnO1xuXG5jb25zdCBJbmRleDogUmVhY3QuRkMgPSAoKSA9PiAoXG4gIDxMYXlvdXQgcHJvdGVjdGVkQ29udGVudD5cbiAgICA8Q2VudGVyIHc9XCIxMDAlXCIgYmc9XCJ5ZWxsb3cuMjAwXCI+XG4gICAgICA8U3Bpbm5lciBzaXplPVwieGxcIiB0aGlja25lc3M9XCI4cHhcIiAvPlxuICAgIDwvQ2VudGVyPlxuICA8L0xheW91dD5cbik7XG5cbmV4cG9ydCBkZWZhdWx0IEluZGV4O1xuIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/pages/index.tsx\n");

/***/ }),

/***/ "@chakra-ui/react":
/*!***********************************!*\
  !*** external "@chakra-ui/react" ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"@chakra-ui/react\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAY2hha3JhLXVpL3JlYWN0XCI/M2I2NSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSIsImZpbGUiOiJAY2hha3JhLXVpL3JlYWN0LmpzIiwic291cmNlc0NvbnRlbnQiOlsibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQGNoYWtyYS11aS9yZWFjdFwiKTsiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///@chakra-ui/react\n");

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"axios\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJheGlvc1wiPzcwYzYiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEiLCJmaWxlIjoiYXhpb3MuanMiLCJzb3VyY2VzQ29udGVudCI6WyJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJheGlvc1wiKTsiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///axios\n");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"next/router\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJuZXh0L3JvdXRlclwiP2Q4M2UiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEiLCJmaWxlIjoibmV4dC9yb3V0ZXIuanMiLCJzb3VyY2VzQ29udGVudCI6WyJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L3JvdXRlclwiKTsiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///next/router\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"react\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWFjdFwiPzU4OGUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEiLCJmaWxlIjoicmVhY3QuanMiLCJzb3VyY2VzQ29udGVudCI6WyJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdFwiKTsiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///react\n");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"react/jsx-dev-runtime\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIj9jZDkwIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBIiwiZmlsZSI6InJlYWN0L2pzeC1kZXYtcnVudGltZS5qcyIsInNvdXJjZXNDb250ZW50IjpbIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiKTsiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///react/jsx-dev-runtime\n");

/***/ }),

/***/ "swr":
/*!**********************!*\
  !*** external "swr" ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"swr\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJzd3JcIj9jMjg5Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBIiwiZmlsZSI6InN3ci5qcyIsInNvdXJjZXNDb250ZW50IjpbIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInN3clwiKTsiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///swr\n");

/***/ })

/******/ });