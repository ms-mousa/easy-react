module.exports = {
  jwtSecret: process.env.JWT_SECRET || '1ae74b80-2fb4-4178-ad90-dc3368d0f28c'
};