export const GET_USER_PERMISSIONS = 'StrapiAdmin/PermissionsManager/GET_USER_PERMISSIONS';
export const GET_USER_PERMISSIONS_ERROR =
  'StrapiAdmin/PermissionsManager/GET_USER_PERMISSIONS_ERROR';
export const GET_USER_PERMISSIONS_SUCCEEDED =
  'StrapiAdmin/PermissionsManager/GET_USER_PERMISSIONS_SUCCEEDED';
