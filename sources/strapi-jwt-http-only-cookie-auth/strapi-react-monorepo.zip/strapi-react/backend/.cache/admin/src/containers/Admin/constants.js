/*
 *
 * Admin constants
 *
 */

export const SET_APP_ERROR = 'StrapiAdmin/Admin/SET_APP_ERROR';
export const GET_STRAPI_LATEST_RELEASE_SUCCEEDED =
  'StrapiAdmin/Admin/GET_STRAPI_LATEST_RELEASE_SUCCEEDED';
