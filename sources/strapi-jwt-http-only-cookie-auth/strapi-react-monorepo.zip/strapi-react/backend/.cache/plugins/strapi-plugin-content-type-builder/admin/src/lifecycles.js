/*
 *
 * SET THE HOOKS TO ENABLE THE MAGIC OF STRAPI.
 * -------------------------------------------
 *
 * Secure, customise and enhance your project by setting
 * the hooks via this file.
 *
 */

function lifecycles() {}

export default lifecycles;
