import { createContext } from 'react';

const DataManagerContext = createContext();

export default DataManagerContext;
